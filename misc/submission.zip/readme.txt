1. Team Name: ETH_CVL
2. Team Member: Limin Wang, Wen Li
3. Team Affiliation: ETH Zurich
4. Method Description (At least 100 words): Our method is based on the AlexNet……
5. Entry Description:
Entry 1: single model A
Entry 2: single model B
Entry 3: fusion A and B with average
Entry 4: fusion A and B with weighted average
Entry 5: fusion A and B with different weights